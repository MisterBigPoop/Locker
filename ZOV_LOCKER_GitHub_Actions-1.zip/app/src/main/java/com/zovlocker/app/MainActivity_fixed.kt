package com.zovlocker.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("locker_secure", Context.MODE_PRIVATE) }
    private var entered = ""
    private var stage = Stage.UNLOCK
    private var pendingPin = ""
    private lateinit var status: TextView
    private lateinit var dots: TextView
    private lateinit var keypad: LinearLayout

    private enum class Stage { SET_PIN, CONFIRM_PIN, UNLOCK, UNLOCKED }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Color.rgb(9, 11, 16)
        window.navigationBarColor = Color.rgb(9, 11, 16)
        stage = if (prefs.contains("pin_hash") && prefs.contains("pin_salt")) Stage.UNLOCK else Stage.SET_PIN
        render()
    }

    override fun onStart() {
        super.onStart()
        hideSystemBars()
    }

    override fun onStop() {
        super.onStop()
        entered = ""
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(24), dp(28), dp(24))
            setBackgroundColor(Color.rgb(9, 11, 16))
        }

        val brand = TextView(this).apply {
            text = "ZOV"
            textSize = 38f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "SECURE APP LOCK"
            textSize = 12f
            letterSpacing = 0.22f
            setTextColor(Color.rgb(229, 57, 53))
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(32)))

        status = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(26), 0, dp(18))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(76)))

        dots = TextView(this).apply {
            textSize = 27f
            letterSpacing = 0.3f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(dots, LinearLayout.LayoutParams(-1, dp(48)))

        keypad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        if (stage == Stage.UNLOCKED) {
            dots.visibility = View.GONE
            val done = Button(this).apply {
                text = "CLOSE LOCKER"
                textSize = 16f
                setTextColor(Color.WHITE)
                background = rounded(Color.rgb(174, 35, 38))
                setOnClickListener { finish() }
            }
            root.addView(done, LinearLayout.LayoutParams(-1, dp(58)))
        } else {
            root.addView(keypad, LinearLayout.LayoutParams(-1, dp(270)))
        }

        val footer = TextView(this).apply {
            text = "Your device remains under your control"
            textSize = 11f
            setTextColor(Color.rgb(125, 132, 145))
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(footer, matchWrap())
        setContentView(root)
        buildKeypad()
        updateLabels()
    }

    private fun buildKeypad() {
        keypad.removeAllViews()
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"),
            listOf("7", "8", "9"), listOf("⌫", "0", "✓"))
        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key ->
                val button = Button(this).apply {
                    text = key
                    textSize = 22f
                    setTextColor(Color.WHITE)
                    background = rounded(if (key == "✓") Color.rgb(174, 35, 38) else Color.rgb(28, 32, 42))
                    isAllCaps = false
                    setOnClickListener { onKey(key) }
                }
                val lp = LinearLayout.LayoutParams(0, dp(58), 1f).apply {
                    setMargins(dp(6), dp(5), dp(6), dp(5))
                }
                line.addView(button, lp)
            }
            keypad.addView(line, LinearLayout.LayoutParams(-1, dp(68)))
        }
    }

    private fun onKey(key: String) {
        when (key) {
            "⌫" -> if (entered.isNotEmpty()) entered = entered.dropLast(1)
            "✓" -> submitPin()
            else -> if (entered.length < 8) entered += key
        }
        updateLabels()
    }

    private fun submitPin() {
        when (stage) {
            Stage.SET_PIN -> {
                if (entered.length < 4) {
                    status.text = "Use at least 4 digits"
                    return
                }
                pendingPin = entered
                entered = ""
                stage = Stage.CONFIRM_PIN
            }
            Stage.CONFIRM_PIN -> {
                if (entered == pendingPin) {
                    val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                    val hash = derive(entered, salt)
                    prefs.edit().putString("pin_salt", salt.toHex())
                        .putString("pin_hash", hash.toHex()).apply()
                    entered = ""
                    pendingPin = ""
                    stage = Stage.UNLOCK
                } else {
                    entered = ""
                    pendingPin = ""
                    stage = Stage.SET_PIN
                    status.text = "PINs did not match. Create again."
                }
            }
            Stage.UNLOCK -> {
                val salt = prefs.getString("pin_salt", null)?.hexToBytes()
                val expected = prefs.getString("pin_hash", null)?.hexToBytes()
                if (salt != null && expected != null && constantTimeEquals(derive(entered, salt), expected)) {
                    entered = ""
                    stage = Stage.UNLOCKED
                    // This app lock protects the app screen only; it does not unlock Android itself.
                    render()
                    return
                } else {
                    entered = ""
                    status.text = "Incorrect PIN. Try again."
                }
            }
            Stage.UNLOCKED -> return
        }
        updateLabels()
    }

    private fun updateLabels() {
        status.text = when (stage) {
            Stage.SET_PIN -> "Create a PIN (4–8 digits)"
            Stage.CONFIRM_PIN -> "Confirm your PIN"
            Stage.UNLOCK -> "Enter PIN to unlock"
            Stage.UNLOCKED -> "App access granted"
        }
        if (stage != Stage.UNLOCKED) {
            dots.text = "● ".repeat(entered.length) + "○ ".repeat(8 - entered.length)
        }
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
        if (a.size != b.size) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].toInt() xor b[i].toInt())
        return diff == 0
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes(): ByteArray = chunked(2).map { it.toInt(16).toByte() }.toByteArray()

    override fun onBackPressed() {
        // Prevents accidental Back navigation only; Android system exit controls remain available.
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(16).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
